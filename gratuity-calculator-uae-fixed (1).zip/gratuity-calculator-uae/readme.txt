=== UAE Gratuity Calculator 2026 ===
Contributors: kemeronkeng
Tags: uae gratuity, end of service, mohre, gratuity calculator, uae labor law
Requires at least: 5.5
Tested up to: 6.9
Stable tag: 3.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

MOHRE-compliant UAE End-of-Service Gratuity Calculator. Embed easily with a shortcode.

== Description ==

The **UAE Gratuity Calculator 2026** is a fully MOHRE-compliant end-of-service gratuity calculator for the United Arab Emirates. It helps employees and employers accurately calculate gratuity entitlements based on UAE Labor Law.

### Key Features

* ✅ MOHRE-compliant gratuity calculations
* ✅ Supports both limited and unlimited contracts
* ✅ Handles resignation and termination scenarios
* ✅ Arabic (RTL) and English language support
* ✅ Dark mode support
* ✅ Easy shortcode embed: `[uae_gratuity_calculator]`
* ✅ Mobile responsive design
* ✅ No external dependencies — runs entirely in browser

### How to Use

1. Install and activate the plugin.
2. Add the shortcode `[uae_gratuity_calculator]` to any page or post.
3. The calculator will appear and users can calculate their gratuity instantly.

### Shortcode

`[uae_gratuity_calculator]`

### About UAE Gratuity Law

Under UAE Labor Law, employees are entitled to end-of-service gratuity based on their years of service and basic salary. This plugin accurately implements the current MOHRE calculation rules for 2026.

== Installation ==

1. Upload the `gratuity-calculator-uae` folder to the `/wp-content/plugins/` directory, OR install directly through the WordPress plugin screen.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Go to any page or post and add the shortcode: `[uae_gratuity_calculator]`
4. The calculator will be displayed on your page.

== Frequently Asked Questions ==

= How do I add the calculator to my page? =

Simply add the shortcode `[uae_gratuity_calculator]` to any page, post, or widget area that supports shortcodes.

= Is this calculator compliant with UAE Labor Law 2026? =

Yes, the calculator is built according to the latest MOHRE (Ministry of Human Resources and Emiratisation) guidelines for 2026.

= Does the calculator support Arabic? =

Yes, the calculator fully supports Arabic with RTL (right-to-left) layout.

= Does it work on mobile devices? =

Yes, the calculator is fully responsive and works on all screen sizes.

= Is there a dark mode? =

Yes, users can toggle dark mode directly within the calculator.

= Does the calculator store any user data? =

No. All calculations are done entirely in the user's browser. No data is sent to any server.

== Screenshots ==

1. Calculator front-end view
2. Dark mode view
3. Arabic (RTL) mode

== Changelog ==

= 3.0.0 =
* Initial public release
* MOHRE 2026 compliant calculations
* Added dark mode support
* Added Arabic / RTL support
* Improved mobile responsiveness

== Upgrade Notice ==

= 3.0.0 =
Initial release. Install and start calculating UAE gratuity instantly.
