<?php
/**
 * Plugin Name: UAE Gratuity Calculator 2026
 * Plugin URI:  https://mygratuityuae.com/
 * Description: MOHRE-compliant UAE End-of-Service Gratuity Calculator. Embed with [uae_gratuity_calculator].
 * Version:     3.0.0
 * Author:      kemeronkeng
 * Author URI:  https://profiles.wordpress.org/kemeronkeng/
 * License:     GPL-2.0+
 * Text Domain: uae-gratuity-calculator-2026
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_shortcode( 'uae_gratuity_calculator', 'ugc_render_calculator' );

function ugc_render_calculator( $atts ) {
    ob_start();
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=DM+Sans:wght@400;500;600;700&family=Noto+Kufi+Arabic:wght@400;600;700&display=swap" rel="stylesheet">

<style>
#ugcApp*,#ugcApp *::before,#ugcApp *::after{box-sizing:border-box;margin:0;padding:0}
#ugcApp{
  --p:#0B3C5D;--pm:#0d4a72;--pl:#1a6496;
  --gold:#D4A843;--goldl:#f0c96a;
  --bg:#f0f4f8;--card:#fff;--calt:#f7f9fc;
  --bdr:#d9e4ee;--txt:#1a2e3d;--muted:#5a7a96;--lite:#8fa8bc;
  --sh:0 4px 24px rgba(11,60,93,.10);--shl:0 12px 48px rgba(11,60,93,.16);
  --r:14px;--rs:8px;--tr:.22s cubic-bezier(.4,0,.2,1);
  font-family:'DM Sans',sans-serif;
  background:var(--bg);
  color:var(--txt);
  transition:background var(--tr),color var(--tr);
  -webkit-font-smoothing:antialiased;
  padding:0 0 72px;
}
#ugcApp.dark{
  --bg:#071e2e;--card:#0d2d45;--calt:#0a2236;
  --bdr:#1a3d5a;--txt:#e8f0f7;--muted:#7aacce;--lite:#4d7a9a;
  --sh:0 4px 24px rgba(0,0,0,.35);--shl:0 12px 48px rgba(0,0,0,.45);
}
#ugcApp.rtl{font-family:'Noto Kufi Arabic',sans-serif;direction:rtl}

.ugc-wrap{max-width:1120px;margin:0 auto;padding:0 16px}

.ugc-hero-bar{
  display:flex;align-items:center;justify-content:space-between;
  gap:12px;padding:18px 0 0;flex-wrap:wrap;
}
.ugc-ctrl-btn{
  display:flex;align-items:center;gap:6px;
  padding:8px 16px;
  border:2px solid var(--bdr);border-radius:50px;
  background:var(--card);color:var(--txt);
  font-family:inherit;font-size:13px;font-weight:600;
  cursor:pointer;transition:all var(--tr);white-space:nowrap;
  box-shadow:var(--sh);
}
.ugc-ctrl-btn:hover{background:var(--p);color:#fff;border-color:var(--p)}

.ugc-title{
  flex:1;text-align:center;
  font-family:'Playfair Display',serif;
  font-size:clamp(16px,2.6vw,28px);font-weight:700;
  color:var(--p);line-height:1.22;letter-spacing:-.01em;
  transition:color var(--tr);
}
#ugcApp.dark .ugc-title{color:var(--goldl)}

.ugc-grid{
  display:grid;grid-template-columns:1fr 1fr;
  gap:24px;align-items:start;margin-top:20px;
}
@media(max-width:768px){
  .ugc-grid{grid-template-columns:1fr}
  .ugc-title{font-size:15px;order:-1;flex:0 0 100%;text-align:center}
}

.ugc-card{
  background:var(--card);border-radius:var(--r);
  box-shadow:var(--sh);border:1px solid var(--bdr);
  overflow:hidden;transition:background var(--tr),border-color var(--tr);
}
.ugc-card-hdr{
  background:var(--p);padding:15px 22px;
  display:flex;align-items:center;gap:9px;
}
.ugc-card-hdr h2{
  font-size:13px;font-weight:700;color:#fff;
  letter-spacing:.06em;text-transform:uppercase;
}
.ugc-body{padding:22px}

.ugc-field{margin-bottom:18px}
.ugc-lbl{
  display:flex;align-items:center;gap:5px;
  font-size:11px;font-weight:700;color:var(--muted);
  letter-spacing:.08em;text-transform:uppercase;margin-bottom:7px;
}
.ugc-inp{
  width:100%;padding:11px 14px;
  border:2px solid var(--bdr);border-radius:var(--rs);
  background:var(--calt);color:var(--txt);
  font-family:inherit;font-size:15px;font-weight:500;
  outline:none;transition:border-color var(--tr),background var(--tr);
  -webkit-appearance:none;display:block;
}
.ugc-inp:focus{border-color:var(--p);box-shadow:0 0 0 3px rgba(11,60,93,.10)}
.ugc-inp::placeholder{color:var(--lite)}

.ugc-tg{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.ugc-tb{
  display:flex;flex-direction:column;gap:3px;
  padding:12px 14px;
  border:2px solid var(--bdr);border-radius:var(--rs);
  background:var(--calt);cursor:pointer;
  transition:border-color var(--tr),border-width var(--tr);
  text-align:left;font-family:inherit;color:var(--txt);width:100%;
}
#ugcApp.rtl .ugc-tb{text-align:right}
.ugc-tb .ti{font-size:17px}
.ugc-tb .tl{font-size:13px;font-weight:700;color:var(--txt)}
.ugc-tb .ts{font-size:11px;color:var(--lite)}
.ugc-tb.on{border-color:#0B3C5D;border-width:2.5px}
#ugcApp.dark .ugc-tb.on{border-color:var(--goldl)}
.ugc-tb.on .tl{color:var(--p);font-weight:800}
#ugcApp.dark .ugc-tb.on .tl{color:var(--goldl)}

.ugc-calc{
  width:100%;margin-top:22px;padding:15px;
  background:var(--p);color:#fff;
  font-family:inherit;font-size:15px;font-weight:700;
  letter-spacing:.05em;text-transform:uppercase;
  border:none;border-radius:var(--rs);cursor:pointer;
  display:flex;align-items:center;justify-content:center;gap:8px;
  transition:background var(--tr),transform var(--tr),box-shadow var(--tr);
}
.ugc-calc:hover{background:var(--pl);transform:translateY(-1px);box-shadow:var(--shl)}
.ugc-calc:active{transform:translateY(0)}

.ugc-note{
  margin-top:14px;padding:11px 13px;
  background:rgba(11,60,93,.06);
  border-left:3px solid var(--p);
  border-radius:0 var(--rs) var(--rs) 0;
  font-size:12px;color:var(--muted);line-height:1.6;
}
#ugcApp.rtl .ugc-note{border-left:none;border-right:3px solid var(--p);border-radius:var(--rs) 0 0 var(--rs)}
#ugcApp.dark .ugc-note{background:rgba(255,255,255,.04)}

.ugc-empty{text-align:center;padding:44px 16px}
.ugc-empty .ei{font-size:52px;opacity:.3;margin-bottom:14px}
.ugc-empty p{color:var(--muted);font-size:13px;line-height:1.6}

.ugc-rp{display:none}
.ugc-rp.on{display:block}

.ugc-rhero{
  background:linear-gradient(135deg,#0B3C5D 0%,#0d5480 55%,#0b3c5d 100%);
  border-radius:var(--r);padding:28px 24px;text-align:center;
  margin-bottom:14px;position:relative;overflow:hidden;box-shadow:var(--shl);
}
.ugc-rhero::before{
  content:'';position:absolute;top:-40px;right:-40px;
  width:150px;height:150px;border-radius:50%;
  background:rgba(212,168,67,.12);
}
.ugc-rhero .rl{font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.6);font-weight:600;margin-bottom:7px}
.ugc-rhero .ra{font-family:'Playfair Display',serif;font-size:clamp(30px,6vw,48px);font-weight:700;color:#D4A843;line-height:1;margin-bottom:5px}
.ugc-rhero .rs{font-size:12px;color:rgba(255,255,255,.45)}

.ugc-stats{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px}
.ugc-stat{background:var(--card);border:1px solid var(--bdr);border-radius:var(--rs);padding:14px;transition:background var(--tr)}
.ugc-stat .sl{font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:var(--lite);font-weight:600;margin-bottom:5px;display:flex;align-items:center;gap:4px}
.ugc-stat .sl .dot{width:6px;height:6px;border-radius:50%;flex-shrink:0}
.ugc-stat .sv{font-size:20px;font-weight:700;color:var(--txt)}

.ugc-bk{background:var(--card);border:1px solid var(--bdr);border-radius:var(--rs);overflow:hidden;margin-bottom:14px}
.ugc-bk-hdr{background:var(--calt);padding:11px 15px;font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);border-bottom:1px solid var(--bdr);display:flex;align-items:center;gap:7px}
.ugc-tbl{width:100%;border-collapse:collapse}
.ugc-tbl th{font-size:9px;letter-spacing:.08em;text-transform:uppercase;color:var(--lite);font-weight:700;padding:9px 14px;text-align:left;border-bottom:1px solid var(--bdr)}
#ugcApp.rtl .ugc-tbl th{text-align:right}
.ugc-tbl td{padding:11px 14px;font-size:12px;color:var(--txt);border-bottom:1px solid var(--bdr);transition:color var(--tr)}
.ugc-tbl tr:last-child td{border-bottom:none}
.ugc-tbl .trow-total td{font-weight:700;font-size:13px;background:rgba(11,60,93,.05)}
#ugcApp.dark .ugc-tbl .trow-total td{background:rgba(255,255,255,.04)}

.ugc-badge{display:inline-block;padding:2px 9px;border-radius:50px;font-size:10px;font-weight:600;background:rgba(212,168,67,.15);color:#B8891A;border:1px solid rgba(212,168,67,.3)}
#ugcApp.dark .ugc-badge{color:var(--goldl)}

.ugc-actions{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.ugc-abtn{
  display:flex;align-items:center;justify-content:center;gap:6px;
  padding:12px;border-radius:var(--rs);
  font-family:inherit;font-size:13px;font-weight:600;
  cursor:pointer;transition:all var(--tr);
}
.ugc-abtn.solid{background:var(--p);color:#fff;border:2px solid var(--p)}
.ugc-abtn.solid:hover{background:var(--pl);border-color:var(--pl);transform:translateY(-1px)}
.ugc-abtn.out{background:transparent;color:var(--txt);border:2px solid var(--bdr)}
.ugc-abtn.out:hover{border-color:var(--p);color:var(--p)}

.ugc-disc{
  margin-top:24px;padding:14px;
  background:rgba(212,168,67,.07);
  border:1px solid rgba(212,168,67,.2);
  border-radius:var(--rs);font-size:11px;
  color:var(--muted);line-height:1.6;text-align:center;
}
.ugc-disc strong{color:var(--gold)}

#ugcToast{
  position:fixed;bottom:24px;left:50%;
  transform:translateX(-50%) translateY(70px);
  background:#0B3C5D;color:#fff;
  padding:10px 22px;border-radius:50px;
  font-size:13px;font-weight:600;
  box-shadow:0 12px 48px rgba(11,60,93,.35);
  transition:transform .3s ease;
  z-index:99999;pointer-events:none;
}
#ugcToast.show{transform:translateX(-50%) translateY(0)}

@keyframes ugcFadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
.ugc-rp.on>*{animation:ugcFadeUp .3s ease forwards}
.ugc-rp.on>*:nth-child(2){animation-delay:.05s}
.ugc-rp.on>*:nth-child(3){animation-delay:.1s}
.ugc-rp.on>*:nth-child(4){animation-delay:.15s}
.ugc-rp.on>*:nth-child(5){animation-delay:.19s}

@media(max-width:480px){
  .ugc-body{padding:14px}
  .ugc-actions{grid-template-columns:1fr}
}
</style>

<div id="ugcApp">
<div class="ugc-wrap">

  <div class="ugc-hero-bar">
    <button class="ugc-ctrl-btn" id="ugcLangBtn">🌐 <span id="ugcLangTxt">عربي</span></button>
    <div class="ugc-title" id="ugcTitle">Online Gratuity Calculator UAE 2026 (MOHRE Updated)</div>
    <button class="ugc-ctrl-btn" id="ugcThemeBtn"><span id="ugcThemeIco">🌙</span> <span id="ugcThemeTxt">Dark</span></button>
  </div>

  <div class="ugc-grid">

    <div class="ugc-card">
      <div class="ugc-card-hdr"><span>📋</span><h2 id="ugcDetailsH">YOUR DETAILS</h2></div>
      <div class="ugc-body">

        <div class="ugc-field">
          <div class="ugc-lbl">💰 <span id="lSalary">Basic Salary (AED)</span></div>
          <input type="number" id="ugcSalary" class="ugc-inp" placeholder="e.g. 5000" min="0" step="0.01">
        </div>

        <div class="ugc-field">
          <div class="ugc-lbl">📅 <span id="lJoin">Joining Date</span></div>
          <input type="date" id="ugcJoinDate" class="ugc-inp">
        </div>

        <div class="ugc-field">
          <div class="ugc-lbl">📅 <span id="lLast">Last Working Day</span></div>
          <input type="date" id="ugcLastDay" class="ugc-inp">
        </div>

        <div class="ugc-field">
          <div class="ugc-lbl">📄 <span id="lContract">Contract Type</span></div>
          <div class="ugc-tg">
            <button class="ugc-tb on" id="tLtd" type="button">
              <span class="ti">📝</span>
              <span class="tl" id="lLtd">Limited</span>
              <span class="ts" id="lLtdS">Fixed term</span>
            </button>
            <button class="ugc-tb" id="tUnl" type="button">
              <span class="ti">📃</span>
              <span class="tl" id="lUnl">Unlimited</span>
              <span class="ts" id="lUnlS">Open-ended</span>
            </button>
          </div>
        </div>

        <div class="ugc-field">
          <div class="ugc-lbl">🚪 <span id="lReason">Leaving Reason</span></div>
          <div class="ugc-tg">
            <button class="ugc-tb on" id="tTerm" type="button">
              <span class="ti">⚡</span>
              <span class="tl" id="lTerm">Termination</span>
              <span class="ts" id="lTermS">By employer</span>
            </button>
            <button class="ugc-tb" id="tRes" type="button">
              <span class="ti">✋</span>
              <span class="tl" id="lRes">Resignation</span>
              <span class="ts" id="lResS">By employee</span>
            </button>
          </div>
        </div>

        <div class="ugc-field">
          <div class="ugc-lbl">⏸️ <span id="lUnpaid">Unpaid Leave Days</span>
            <span style="font-size:9px;background:rgba(11,60,93,.09);color:var(--muted);padding:2px 7px;border-radius:50px;margin-left:4px" id="lOpt">Optional</span>
          </div>
          <input type="number" id="ugcUnpaid" class="ugc-inp" value="0" min="0">
        </div>

        <button class="ugc-calc" id="ugcCalcBtn" type="button">⚡ <span id="lCalc">Calculate Gratuity</span></button>

        <div class="ugc-note" id="ugcNote">Gratuity is calculated on <strong>basic salary only</strong>, excluding allowances. Minimum 1 year of service required.</div>

      </div>
    </div>

    <div class="ugc-card">
      <div class="ugc-card-hdr"><span>📊</span><h2 id="ugcResultsH">YOUR RESULTS</h2></div>
      <div class="ugc-body">

        <div class="ugc-empty" id="ugcEmpty">
          <div class="ei">🏦</div>
          <p id="lEmpty">Fill in your details and click <strong>Calculate Gratuity</strong> to see your end-of-service entitlement.</p>
        </div>

        <div class="ugc-rp" id="ugcRP">

          <div class="ugc-rhero">
            <div class="rl" id="lTotalEOS">TOTAL END-OF-SERVICE GRATUITY</div>
            <div class="ra" id="resAmt">AED 0</div>
            <div class="rs" id="resAmtSub">0 AED</div>
          </div>

          <div class="ugc-stats">
            <div class="ugc-stat">
              <div class="sl"><span class="dot" style="background:#4a9edd"></span><span id="lDur">SERVICE DURATION</span></div>
              <div class="sv" id="resDur">—</div>
            </div>
            <div class="ugc-stat">
              <div class="sl"><span class="dot" style="background:#22c55e"></span><span id="lDaily">DAILY WAGE</span></div>
              <div class="sv" id="resDaily">—</div>
            </div>
            <div class="ugc-stat">
              <div class="sl"><span class="dot" style="background:#22c55e"></span><span id="lEff">EFFECTIVE YEARS</span></div>
              <div class="sv" id="resEff">—</div>
            </div>
            <div class="ugc-stat">
              <div class="sl"><span class="dot" style="background:#f59e0b"></span><span id="lDaysE">DAYS EARNED</span></div>
              <div class="sv" id="resDaysE">—</div>
            </div>
          </div>

          <div class="ugc-bk">
            <div class="ugc-bk-hdr">📈 <span id="lBk">YEAR-BY-YEAR BREAKDOWN</span></div>
            <table class="ugc-tbl">
              <thead><tr>
                <th id="thPer">PERIOD</th>
                <th id="thRate">RATE</th>
                <th id="thDays">DAYS</th>
                <th id="thAmt">AMOUNT (AED)</th>
              </tr></thead>
              <tbody id="resTbody"></tbody>
            </table>
          </div>

          <div class="ugc-actions">
            <button class="ugc-abtn out" id="ugcCopyBtn" type="button">📋 <span id="lCopy">Copy Results</span></button>
            <button class="ugc-abtn solid" id="ugcPdfBtn" type="button">⬇️ <span id="lPdf">Download PDF</span></button>
          </div>

        </div>
      </div>
    </div>

  </div>

  <div class="ugc-disc">⚠️ <strong>Disclaimer:</strong> <span id="lDisc">This calculator is for informational purposes only. Figures are based on UAE Labour Law (Federal Decree-Law No. 33 of 2021). Always consult MOHRE or a legal professional for official advice.</span></div>

</div>
</div>

<div id="ugcToast"></div>

<script>
(function(){
  var S={lang:'en',dark:false,contract:'limited',reason:'termination',result:null};

  var TX={
    en:{
      title:'Online Gratuity Calculator UAE 2026 (MOHRE Updated)',
      details:'YOUR DETAILS',results:'YOUR RESULTS',
      lSalary:'Basic Salary (AED)',lJoin:'Joining Date',lLast:'Last Working Day',
      lContract:'Contract Type',lLtd:'Limited',lLtdS:'Fixed term',
      lUnl:'Unlimited',lUnlS:'Open-ended',
      lReason:'Leaving Reason',lTerm:'Termination',lTermS:'By employer',
      lRes:'Resignation',lResS:'By employee',
      lUnpaid:'Unpaid Leave Days',lOpt:'Optional',
      lCalc:'Calculate Gratuity',
      note:'Gratuity is calculated on <strong>basic salary only</strong>, excluding allowances. Minimum 1 year of service required.',
      lEmpty:'Fill in your details and click <strong>Calculate Gratuity</strong> to see your end-of-service entitlement.',
      lTotalEOS:'TOTAL END-OF-SERVICE GRATUITY',
      lDur:'SERVICE DURATION',lDaily:'DAILY WAGE',lEff:'EFFECTIVE YEARS',lDaysE:'DAYS EARNED',
      lBk:'YEAR-BY-YEAR BREAKDOWN',
      thPer:'PERIOD',thRate:'RATE',thDays:'DAYS',thAmt:'AMOUNT (AED)',
      lCopy:'Copy Results',lPdf:'Download PDF',
      disc:'This calculator is for informational purposes only. Figures are based on UAE Labour Law (Federal Decree-Law No. 33 of 2021). Always consult MOHRE or a legal professional for official advice.',
      langBtn:'\u0639\u0631\u0628\u064a',themeLight:'Light',themeDark:'Dark',
      yr15:'Years 1\u20135',yr5p:'Years After 5',total:'Total',dyr:'Days/yr',aed:'AED',
      eS:'\u26a0\ufe0f Enter a valid basic salary.',
      eD:'\u26a0\ufe0f Enter valid joining and last working dates.',
      eO:'\u26a0\ufe0f Last working day must be after joining date.',
      cp:'\u2705 Results copied!',
      noG:'Gratuity not applicable (less than 1 year of service).'
    },
    ar:{
      title:'\u062d\u0627\u0633\u0628\u0629 \u0645\u0643\u0627\u0641\u0623\u0629 \u0646\u0647\u0627\u064a\u0629 \u0627\u0644\u062e\u062f\u0645\u0629 \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062a 2026 (\u0645\u062d\u062f\u0651\u062b \u0648\u0641\u0642 \u0648\u0632\u0627\u0631\u0629 \u0627\u0644\u0645\u0648\u0627\u0631\u062f \u0627\u0644\u0628\u0634\u0631\u064a\u0629)',
      details:'\u0628\u064a\u0627\u0646\u0627\u062a\u0643',results:'\u0646\u062a\u0627\u0626\u062c\u0643',
      lSalary:'\u0627\u0644\u0631\u0627\u062a\u0628 \u0627\u0644\u0623\u0633\u0627\u0633\u064a (\u062f\u0631\u0647\u0645)',
      lJoin:'\u062a\u0627\u0631\u064a\u062e \u0627\u0644\u0627\u0644\u062a\u062d\u0627\u0642',
      lLast:'\u0622\u062e\u0631 \u064a\u0648\u0645 \u0639\u0645\u0644',
      lContract:'\u0646\u0648\u0639 \u0627\u0644\u0639\u0642\u062f',
      lLtd:'\u0645\u062d\u062f\u062f \u0627\u0644\u0645\u062f\u0629',lLtdS:'\u0639\u0642\u062f \u062b\u0627\u0628\u062a',
      lUnl:'\u063a\u064a\u0631 \u0645\u062d\u062f\u062f',lUnlS:'\u0639\u0642\u062f \u0645\u0641\u062a\u0648\u062d',
      lReason:'\u0633\u0628\u0628 \u0645\u063a\u0627\u062f\u0631\u0629 \u0627\u0644\u0639\u0645\u0644',
      lTerm:'\u0625\u0646\u0647\u0627\u0621 \u0627\u0644\u062e\u062f\u0645\u0629',lTermS:'\u0645\u0646 \u0642\u0650\u0628\u064e\u0644 \u0635\u0627\u062d\u0628 \u0627\u0644\u0639\u0645\u0644',
      lRes:'\u0627\u0633\u062a\u0642\u0627\u0644\u0629',lResS:'\u0645\u0646 \u0642\u0650\u0628\u064e\u0644 \u0627\u0644\u0645\u0648\u0638\u0641',
      lUnpaid:'\u0623\u064a\u0627\u0645 \u0627\u0644\u0625\u062c\u0627\u0632\u0629 \u063a\u064a\u0631 \u0645\u062f\u0641\u0648\u0639\u0629',lOpt:'\u0627\u062e\u062a\u064a\u0627\u0631\u064a',
      lCalc:'\u0627\u062d\u0633\u0628 \u0645\u0643\u0627\u0641\u0623\u0629 \u0646\u0647\u0627\u064a\u0629 \u0627\u0644\u062e\u062f\u0645\u0629',
      note:'\u062a\u064f\u062d\u062a\u0633\u0628 \u0627\u0644\u0645\u0643\u0627\u0641\u0623\u0629 \u0639\u0644\u0649 <strong>\u0627\u0644\u0631\u0627\u062a\u0628 \u0627\u0644\u0623\u0633\u0627\u0633\u064a \u0641\u0642\u0637</strong> \u062f\u0648\u0646 \u0627\u0644\u0628\u062f\u0644\u0627\u062a. \u064a\u0634\u062a\u0631\u0637 \u0627\u0644\u062d\u062f \u0627\u0644\u0623\u062f\u0646\u0649 \u0633\u0646\u0629 \u062e\u062f\u0645\u0629.',
      lEmpty:'\u0623\u062f\u062e\u0644 \u0628\u064a\u0627\u0646\u0627\u062a\u0643 \u0648\u0627\u0636\u063a\u0637 <strong>\u0627\u062d\u0633\u0628 \u0645\u0643\u0627\u0641\u0623\u0629 \u0646\u0647\u0627\u064a\u0629 \u0627\u0644\u062e\u062f\u0645\u0629</strong> \u0644\u0645\u0639\u0631\u0641\u0629 \u0645\u0633\u062a\u062d\u0642\u0627\u062a\u0643.',
      lTotalEOS:'\u0625\u062c\u0645\u0627\u0644\u064a \u0645\u0643\u0627\u0641\u0623\u0629 \u0646\u0647\u0627\u064a\u0629 \u0627\u0644\u062e\u062f\u0645\u0629',
      lDur:'\u0645\u062f\u0629 \u0627\u0644\u062e\u062f\u0645\u0629',lDaily:'\u0627\u0644\u0623\u062c\u0631 \u0627\u0644\u064a\u0648\u0645\u064a',
      lEff:'\u0627\u0644\u0633\u0646\u0648\u0627\u062a \u0627\u0644\u0641\u0639\u0644\u064a\u0629',lDaysE:'\u0627\u0644\u0623\u064a\u0627\u0645 \u0627\u0644\u0645\u0633\u062a\u062d\u0642\u0629',
      lBk:'\u0627\u0644\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0633\u0646\u0648\u064a\u0629',
      thPer:'\u0627\u0644\u0641\u062a\u0631\u0629',thRate:'\u0627\u0644\u0645\u0639\u062f\u0644',thDays:'\u0627\u0644\u0623\u064a\u0627\u0645',thAmt:'\u0627\u0644\u0645\u0628\u0644\u063a (\u062f\u0631\u0647\u0645)',
      lCopy:'\u0646\u0633\u062e \u0627\u0644\u0646\u062a\u0627\u0626\u062c',lPdf:'\u062a\u062d\u0645\u064a\u0644 PDF',
      disc:'\u0647\u0630\u0647 \u0627\u0644\u062d\u0627\u0633\u0628\u0629 \u0644\u0644\u0623\u063a\u0631\u0627\u0636 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a\u064a\u0629 \u0641\u0642\u0637. \u062a\u0633\u062a\u0646\u062f \u0627\u0644\u0623\u0631\u0642\u0627\u0645 \u0625\u0644\u0649 \u0642\u0627\u0646\u0648\u0646 \u0627\u0644\u0639\u0645\u0644 \u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062a\u064a. \u064a\u064f\u0631\u062c\u0649 \u0627\u0644\u0631\u062c\u0648\u0639 \u0625\u0644\u0649 \u0648\u0632\u0627\u0631\u0629 \u0627\u0644\u0645\u0648\u0627\u0631\u062f \u0627\u0644\u0628\u0634\u0631\u064a\u0629 \u0623\u0648 \u0645\u0633\u062a\u0634\u0627\u0631 \u0642\u0627\u0646\u0648\u0646\u064a.',
      langBtn:'English',themeLight:'\u0641\u0627\u062a\u062d',themeDark:'\u062f\u0627\u0643\u0646',
      yr15:'\u0627\u0644\u0633\u0646\u0648\u0627\u062a 1\u20135',yr5p:'\u0628\u0639\u062f \u0627\u0644\u0633\u0646\u0629 \u0627\u0644\u062e\u0627\u0645\u0633\u0629',
      total:'\u0627\u0644\u0645\u062c\u0645\u0648\u0639',dyr:'\u064a\u0648\u0645/\u0633\u0646\u0629',aed:'\u062f\u0631\u0647\u0645',
      eS:'\u26a0\ufe0f \u0627\u0644\u0631\u062c\u0627\u0621 \u0625\u062f\u062e\u0627\u0644 \u0627\u0644\u0631\u0627\u062a\u0628 \u0627\u0644\u0623\u0633\u0627\u0633\u064a \u0628\u0634\u0643\u0644 \u0635\u062d\u064a\u062d.',
      eD:'\u26a0\ufe0f \u0627\u0644\u0631\u062c\u0627\u0621 \u0625\u062f\u062e\u0627\u0644 \u062a\u0648\u0627\u0631\u064a\u062e \u0635\u062d\u064a\u062d\u0629.',
      eO:'\u26a0\ufe0f \u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 \u0622\u062e\u0631 \u064a\u0648\u0645 \u0639\u0645\u0644 \u0628\u0639\u062f \u062a\u0627\u0631\u064a\u062e \u0627\u0644\u0627\u0644\u062a\u062d\u0627\u0642.',
      cp:'\u2705 \u062a\u0645 \u0646\u0633\u062e \u0627\u0644\u0646\u062a\u0627\u0626\u062c!',
      noG:'\u0644\u0627 \u062a\u064f\u0633\u062a\u062d\u0642 \u0645\u0643\u0627\u0641\u0623\u0629 (\u0623\u0642\u0644 \u0645\u0646 \u0633\u0646\u0629 \u062e\u062f\u0645\u0629).'
    }
  };

  function t(k){return TX[S.lang][k]||k;}
  function fmtN(n){return n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,',');}
  function g(id){return document.getElementById(id);}
  function st(id,v){var e=g(id);if(e)e.textContent=v;}
  function sh(id,v){var e=g(id);if(e)e.innerHTML=v;}

  function toast(msg){
    var e=g('ugcToast');e.textContent=msg;e.classList.add('show');
    setTimeout(function(){e.classList.remove('show');},2800);
  }

  function applyLang(){
    var app=g('ugcApp');
    var isAr=S.lang==='ar';
    app.classList.toggle('rtl',isAr);
    sh('ugcTitle',t('title'));
    st('ugcDetailsH',t('details'));st('ugcResultsH',t('results'));
    st('lSalary',t('lSalary'));st('lJoin',t('lJoin'));st('lLast',t('lLast'));
    st('lContract',t('lContract'));st('lLtd',t('lLtd'));st('lLtdS',t('lLtdS'));
    st('lUnl',t('lUnl'));st('lUnlS',t('lUnlS'));
    st('lReason',t('lReason'));st('lTerm',t('lTerm'));st('lTermS',t('lTermS'));
    st('lRes',t('lRes'));st('lResS',t('lResS'));
    st('lUnpaid',t('lUnpaid'));st('lOpt',t('lOpt'));st('lCalc',t('lCalc'));
    sh('ugcNote',t('note'));sh('lEmpty',t('lEmpty'));
    st('lTotalEOS',t('lTotalEOS'));st('lDur',t('lDur'));st('lDaily',t('lDaily'));
    st('lEff',t('lEff'));st('lDaysE',t('lDaysE'));st('lBk',t('lBk'));
    st('thPer',t('thPer'));st('thRate',t('thRate'));st('thDays',t('thDays'));st('thAmt',t('thAmt'));
    st('lCopy',t('lCopy'));st('lPdf',t('lPdf'));st('lDisc',t('disc'));
    st('ugcLangTxt',t('langBtn'));
    if(S.result)renderResult(S.result);
  }

  /* LANG */
  g('ugcLangBtn').addEventListener('click',function(){
    S.lang=S.lang==='en'?'ar':'en';
    applyLang();
  });

  /* THEME */
  g('ugcThemeBtn').addEventListener('click',function(){
    S.dark=!S.dark;
    g('ugcApp').classList.toggle('dark',S.dark);
    g('ugcThemeIco').textContent=S.dark?'☀️':'🌙';
    st('ugcThemeTxt',S.dark?t('themeLight'):t('themeDark'));
  });

  /* CONTRACT */
  g('tLtd').addEventListener('click',function(){
    S.contract='limited';
    g('tLtd').classList.add('on');g('tUnl').classList.remove('on');
  });
  g('tUnl').addEventListener('click',function(){
    S.contract='unlimited';
    g('tUnl').classList.add('on');g('tLtd').classList.remove('on');
  });

  /* REASON */
  g('tTerm').addEventListener('click',function(){
    S.reason='termination';
    g('tTerm').classList.add('on');g('tRes').classList.remove('on');
  });
  g('tRes').addEventListener('click',function(){
    S.reason='resignation';
    g('tRes').classList.add('on');g('tTerm').classList.remove('on');
  });

  /* CALC LOGIC */
  function daysBetween(a,b){return Math.round((b-a)/86400000);}
  function getYMD(s,e){
    var sd=new Date(s),ed=new Date(e);
    var y=ed.getFullYear()-sd.getFullYear();
    var m=ed.getMonth()-sd.getMonth();
    var d=ed.getDate()-sd.getDate();
    if(d<0){m--;d+=new Date(ed.getFullYear(),ed.getMonth(),0).getDate();}
    if(m<0){y--;m+=12;}
    return{y:y,m:m,d:d};
  }

  function calcGratuity(salary,jMs,lMs,unpaid,contract,reason){
    var days=daysBetween(jMs,lMs)-(unpaid||0);
    if(days<0)days=0;
    var yrs=days/365;
    var daily=salary/30;
    if(yrs<1)return null;

    var y15=Math.min(yrs,5),d15=y15*21,a15=d15*daily;
    var y5p=Math.max(yrs-5,0),d5p=y5p*30,a5p=d5p*daily;
    var g=a15+a5p;

    var factor=1;
    if(reason==='resignation'&&contract==='unlimited'){
      if(yrs<3)factor=1/3;
      else if(yrs<5)factor=2/3;
    }
    g=Math.min(g*factor,salary*24);

    var rows=[];
    if(y15>0)rows.push({lkey:'yr15',rate:'21',days:parseFloat((d15*factor).toFixed(2)),amount:parseFloat((a15*factor).toFixed(2))});
    if(y5p>0)rows.push({lkey:'yr5p',rate:'30',days:parseFloat((d5p*factor).toFixed(2)),amount:parseFloat((a5p*factor).toFixed(2))});

    return{g:parseFloat(g.toFixed(2)),daily:parseFloat(daily.toFixed(2)),yrs:parseFloat(yrs.toFixed(2)),rows:rows,ymd:getYMD(jMs,lMs)};
  }

  function renderResult(r){
    st('resAmt','AED '+fmtN(r.g));
    st('resAmtSub',fmtN(r.g)+' AED');
    st('resDur',r.ymd.y+'y '+r.ymd.m+'m '+r.ymd.d+'d');
    st('resDaily','AED '+fmtN(r.daily));
    st('resEff',r.yrs.toFixed(2));
    var totalD=r.rows.reduce(function(s,rv){return s+rv.days;},0);
    st('resDaysE',totalD.toFixed(1));
    var tb=g('resTbody');tb.innerHTML='';
    r.rows.forEach(function(row,i){
      var tr=document.createElement('tr');
      tr.innerHTML='<td><span style="display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:50%;background:#0B3C5D;color:#fff;font-size:10px;font-weight:700;margin-right:7px">'+(i+1)+'</span>'+t(row.lkey)+'</td>'+
        '<td><span class="ugc-badge">'+row.rate+' '+t('dyr')+'</span></td>'+
        '<td>'+row.days.toFixed(1)+'</td>'+
        '<td><strong>'+t('aed')+' '+fmtN(row.amount)+'</strong></td>';
      tb.appendChild(tr);
    });
    var tr2=document.createElement('tr');tr2.className='trow-total';
    tr2.innerHTML='<td colspan="2"><strong>'+t('total')+'</strong></td><td><strong>'+totalD.toFixed(1)+'</strong></td><td><strong>'+t('aed')+' '+fmtN(r.g)+'</strong></td>';
    tb.appendChild(tr2);
  }

  /* CALCULATE CLICK */
  g('ugcCalcBtn').addEventListener('click',function(){
    var salary=parseFloat(g('ugcSalary').value);
    var joinVal=g('ugcJoinDate').value;
    var lastVal=g('ugcLastDay').value;
    var unpaid=parseInt(g('ugcUnpaid').value)||0;

    if(!salary||salary<=0){toast(t('eS'));return;}
    if(!joinVal||!lastVal){toast(t('eD'));return;}
    var jMs=new Date(joinVal).getTime();
    var lMs=new Date(lastVal).getTime();
    if(lMs<=jMs){toast(t('eO'));return;}

    var r=calcGratuity(salary,jMs,lMs,unpaid,S.contract,S.reason);

    g('ugcEmpty').style.display='none';
    var rp=g('ugcRP');
    rp.classList.remove('on');
    void rp.offsetWidth;
    rp.classList.add('on');

    if(!r){
      S.result={g:0,daily:salary/30,yrs:0,rows:[],ymd:{y:0,m:0,d:0}};
      st('resAmt','AED 0.00');
      st('resAmtSub',t('noG'));
      st('resDur','—');st('resDaily','AED '+parseFloat(salary/30).toFixed(2));
      st('resEff','< 1');st('resDaysE','0');
      g('resTbody').innerHTML='<tr><td colspan="4" style="text-align:center;color:var(--muted);padding:18px;font-size:12px">'+t('noG')+'</td></tr>';
      return;
    }
    S.result=r;
    renderResult(r);
  });

  /* COPY */
  g('ugcCopyBtn').addEventListener('click',function(){
    if(!S.result)return;
    var r=S.result;
    var txt=t('lTotalEOS')+': AED '+fmtN(r.g)+'\n'+t('lDur')+': '+r.ymd.y+'y '+r.ymd.m+'m '+r.ymd.d+'d\n'+t('lDaily')+': AED '+fmtN(r.daily)+'\n'+t('lEff')+': '+r.yrs.toFixed(2);
    if(navigator.clipboard){navigator.clipboard.writeText(txt).then(function(){toast(t('cp'));}).catch(function(){toast(t('cp'));});}
    else{toast(t('cp'));}
  });

  /* PDF */
  g('ugcPdfBtn').addEventListener('click',function(){
    if(!S.result||S.result.g===0)return;
    var r=S.result;
    var isAr=S.lang==='ar';
    var dir=isAr?'rtl':'ltr';
    var totalD=r.rows.reduce(function(s,rv){return s+rv.days;},0);
    var rowsH='';
    r.rows.forEach(function(row,i){
      rowsH+='<tr><td>'+(i+1)+'. '+t(row.lkey)+'</td><td>'+row.rate+' '+t('dyr')+'</td><td>'+row.days.toFixed(1)+'</td><td><strong>AED '+fmtN(row.amount)+'</strong></td></tr>';
    });
    rowsH+='<tr style="font-weight:700;background:#f0f4f8"><td colspan="2">'+t('total')+'</td><td>'+totalD.toFixed(1)+'</td><td>AED '+fmtN(r.g)+'</td></tr>';

    var html='<!DOCTYPE html><html lang="'+S.lang+'" dir="'+dir+'"><head><meta charset="UTF-8"><title>UAE Gratuity MOHRE 2026</title>'+
      '<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700&family=Noto+Kufi+Arabic:wght@400;600;700&display=swap" rel="stylesheet">'+
      '<style>body{margin:0;padding:24px;font-family:'+(isAr?"'Noto Kufi Arabic'":"'DM Sans'")+',sans-serif;color:#0B3C5D;background:#fff;direction:'+dir+'}'+
      '.hdr{background:#0B3C5D;color:#fff;padding:22px 26px;border-radius:10px;margin-bottom:18px}'+
      '.hdr .l{font-size:10px;letter-spacing:.1em;text-transform:uppercase;opacity:.6;margin-bottom:5px}'+
      '.hdr .a{font-size:36px;font-weight:700;color:#D4A843;margin-bottom:4px}'+
      '.hdr .s{font-size:11px;opacity:.4}'+
      '.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:18px}'+
      '.stat{background:#f0f4f8;border-radius:7px;padding:12px;text-align:center}'+
      '.stat .l{font-size:9px;letter-spacing:.08em;text-transform:uppercase;color:#5a7a96;margin-bottom:3px}'+
      '.stat .v{font-size:17px;font-weight:700;color:#0B3C5D}'+
      'table{width:100%;border-collapse:collapse;margin-bottom:18px;font-size:12px}'+
      'th{background:#0B3C5D;color:#fff;padding:9px 13px;text-align:'+(isAr?'right':'left')+';font-size:9px;letter-spacing:.08em;text-transform:uppercase}'+
      'td{padding:9px 13px;border-bottom:1px solid #d9e4ee;color:#0B3C5D}'+
      '.bar{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;color:#5a7a96;font-size:11px}'+
      '.disc{font-size:10px;color:#7a9ab5;border-top:1px solid #d9e4ee;padding-top:12px;line-height:1.6;text-align:center}'+
      '</style></head><body>'+
      '<div class="bar"><strong style="color:#0B3C5D">\ud83c\uddea\ud83c\udde6 UAE Gratuity Calculator</strong><span>MOHRE 2026 | '+new Date().toLocaleDateString()+'</span></div>'+
      '<div class="hdr"><div class="l">'+t('lTotalEOS')+'</div><div class="a">AED '+fmtN(r.g)+'</div><div class="s">'+fmtN(r.g)+' AED</div></div>'+
      '<div class="stats">'+
      '<div class="stat"><div class="l">'+t('lDur')+'</div><div class="v">'+r.ymd.y+'y '+r.ymd.m+'m '+r.ymd.d+'d</div></div>'+
      '<div class="stat"><div class="l">'+t('lDaily')+'</div><div class="v">AED '+fmtN(r.daily)+'</div></div>'+
      '<div class="stat"><div class="l">'+t('lEff')+'</div><div class="v">'+r.yrs.toFixed(2)+'</div></div>'+
      '<div class="stat"><div class="l">'+t('lDaysE')+'</div><div class="v">'+totalD.toFixed(1)+'</div></div>'+
      '</div>'+
      '<table><thead><tr><th>'+t('thPer')+'</th><th>'+t('thRate')+'</th><th>'+t('thDays')+'</th><th>'+t('thAmt')+'</th></tr></thead><tbody>'+rowsH+'</tbody></table>'+
      '<div class="disc">'+t('disc')+'</div></body></html>';

    var w=window.open('','_blank','width=820,height=720');
    if(w){w.document.open();w.document.write(html);w.document.close();setTimeout(function(){w.print();},700);}
  });

  /* INIT */
  applyLang();
})();
</script>
<?php
    return ob_get_clean();
}
